package contracts

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

type VaxContract struct {
	contractapi.Contract
}
type VaccineBatch struct {
	BatchID         string `json:"batchID"`
	Manufacturer    string `json:"manufacturer"`
	VaccineType     string `json:"vaccineType"`
	ManufactureDate string `json:"manufactureDate"`
	ExpiryDate      string `json:"expiryDate"`
	Quantity        int    `json:"quantity"`

	MinTemp float64 `json:"minTemp"`
	MaxTemp float64 `json:"maxTemp"`

	Status          string         `json:"status"`
	CurrentOwner    string         `json:"currentOwner"`
	TemperatureLogs []TempLog      `json:"temperatureLogs"`
	History         []BatchHistory `json:"history"`
}

type TempLog struct {
	TimeStamp   string  `json:"timestamp"`
	Temperature float64 `json:"temperature"`
}
type TemperatureLogEntry struct {
	BatchID  string    `json:"batchID"`
	TempLogs []TempLog `json:"tempLogs"`
}

type BatchHistory struct {
	TimeStamp string `json:"timestamp"`
	Status    string `json:"status"`
	Owner     string `json:"owner"`
}

func getCollectionName() string {
	collectionName := "BatchCollection"
	return collectionName
}

// Org1
func (v *VaxContract) VaccineExists(ctx contractapi.TransactionContextInterface, BatchID string) (bool, error) {
	collectionName := getCollectionName()
	data, err := ctx.GetStub().GetPrivateData(collectionName, BatchID)

	if err != nil {
		return false, fmt.Errorf("failed to read from world state: %v", err)
	}
	return data != nil, nil
}

// Org1
func (v *VaxContract) CreateBatch(ctx contractapi.TransactionContextInterface) (string, error) {
	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", err
	}

	if clientOrgID != "Org1MSP" {
		return "", fmt.Errorf("user under following MSPID: %v can't perform this action", clientOrgID)
	}

	transientMap, err := ctx.GetStub().GetTransient()
	if err != nil {
		return "", fmt.Errorf("failed to get transient input: %v", err)
	}

	vaccineJSON, ok := transientMap["vaccine"]
	if !ok {
		return "", fmt.Errorf("vaccine key not found in transient map")
	}

	var vaccine VaccineBatch
	err = json.Unmarshal(vaccineJSON, &vaccine)
	if err != nil {
		return "", fmt.Errorf("failed to unmarshal transient input: %v", err)
	}

	// Check if batch already exists
	exists, err := v.VaccineExists(ctx, vaccine.BatchID)
	if err != nil {
		return "", err
	}
	if exists {
		return "", fmt.Errorf("the batch %s already exists", vaccine.BatchID)
	}

	// Set internal fields (not provided by client)
	vaccine.Status = "Created"
	vaccine.CurrentOwner = vaccine.Manufacturer
	vaccine.TemperatureLogs = []TempLog{}
	vaccine.History = []BatchHistory{{
		TimeStamp: time.Now().Format(time.RFC1123),
		Status:    "Created",
		Owner:     vaccine.Manufacturer,
	}}

	vaccineBytes, err := json.Marshal(vaccine)
	if err != nil {
		return "", err
	}

	collectionName := getCollectionName()
	err = ctx.GetStub().PutPrivateData(collectionName, vaccine.BatchID, vaccineBytes)
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("Successfully added vaccine batch: %v", vaccine.BatchID), nil
}

//Org 1 && Org 3

func (v *VaxContract) ReadBatch(ctx contractapi.TransactionContextInterface, batchID string) (*VaccineBatch, error) {
	collectionName := getCollectionName()
	bytes, err := ctx.GetStub().GetPrivateData(collectionName, batchID)
	if err != nil {
		return nil, fmt.Errorf("failed to read from world state: %v", err)
	}
	if bytes == nil {
		return nil, fmt.Errorf("the vaccine %s does not exist", batchID)
	}
	var vaccine VaccineBatch
	err = json.Unmarshal(bytes, &vaccine)
	if err != nil {
		return nil, fmt.Errorf("could not unmarshal world state data to type VaccinBatch")
	}
	return &vaccine, nil
}

// Org 1
// func (v *VaxContract) DeleteBatch(ctx contractapi.TransactionContextInterface, batchID string) (string, error) {
// 	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
// 	if err != nil {
// 		return "", err
// 	}
// 	if clientOrgID == "Org1MSP" {

// 		exists, err := v.VaccineExists(ctx, batchID)
// 		if err != nil {
// 			return "", fmt.Errorf("Could not read from world state. %s", err)
// 		} else if !exists {
// 			return "", fmt.Errorf("The asset %s does not exist", batchID)
// 		}

// 		err = ctx.GetStub().DelPrivateData("BatchCollection", batchID)
// 		if err != nil {
// 			return "", err
// 		} else {
// 			return fmt.Sprintf("Vaccine with id %v is deleted from the world state.", batchID), nil
// 		}

//		} else {
//			return "", fmt.Errorf("User under following MSP:%v cannot able to perform this action", clientOrgID)
//		}
//	}
func (v *VaxContract) DeleteBatch(ctx contractapi.TransactionContextInterface, batchID string) (string, error) {
	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", err
	}

	if clientOrgID != "Org1MSP" {
		return "", fmt.Errorf("User under MSP %v cannot perform this action", clientOrgID)
	}

	exists, err := v.VaccineExists(ctx, batchID)
	if err != nil {
		return "", fmt.Errorf("Could not read from world state. %s", err)
	} else if !exists {
		return "", fmt.Errorf("The asset %s does not exist", batchID)
	}

	err = ctx.GetStub().DelPrivateData("BatchCollection", batchID)
	if err != nil {
		return "", fmt.Errorf("Failed to delete private data: %s", err)
	}

	// Optional: delete from public state and emit event
	_ = ctx.GetStub().DelState(batchID)
	_ = ctx.GetStub().SetEvent("DeleteBatchEvent", []byte(batchID))

	return fmt.Sprintf("Vaccine with id %v is deleted from the world state.", batchID), nil
}

//Org 1  & Org 3

func (v *VaxContract) GetAllBatch(ctx contractapi.TransactionContextInterface) ([]*VaccineBatch, error) {
	queryString := `{
		"selector": {},
		"sort": [{"batchID": "desc"}]
	}`

	resultsIterator, err := ctx.GetStub().GetPrivateDataQueryResult("BatchCollection", queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	return vaxResultIteratorFunction(resultsIterator)
}

func vaxResultIteratorFunction(resultsIterator shim.StateQueryIteratorInterface) ([]*VaccineBatch, error) {

	var vaccines []*VaccineBatch

	for resultsIterator.HasNext() {

		queryResult, err := resultsIterator.Next()

		if err != nil {

			return nil, err

		}

		var vaccine VaccineBatch

		err = json.Unmarshal(queryResult.Value, &vaccine)

		if err != nil {

			return nil, err

		}

		if vaccine.TemperatureLogs == nil {
			vaccine.TemperatureLogs = []TempLog{}
		}

		vaccines = append(vaccines, &vaccine)

	}

	return vaccines, nil

}

func (v *VaxContract) DeliverBatch(ctx contractapi.TransactionContextInterface, batchID string) error {
	// Check that caller is Org1
	org, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return fmt.Errorf("could not get MSP ID: %v", err)
	}
	if org != "Org1MSP" {
		return fmt.Errorf("unauthorized: only Org1 can deliver batches")
	}

	vaccine, err := v.ReadBatch(ctx, batchID)
	if err != nil {
		return fmt.Errorf("failed to read batch: %v", err)
	}

	if vaccine.Status != "Created" {
		return fmt.Errorf("batch %s is not in a deliverable state (current: %s)", batchID, vaccine.Status)
	}

	vaccine.Status = "In-Transit"

	vaccineBytes, err := json.Marshal(vaccine)
	if err != nil {
		return err
	}

	return ctx.GetStub().PutState(batchID, vaccineBytes)
}

// func (v *VaxContract) ReceiveFromOrg1(ctx contractapi.TransactionContextInterface, batchID string) error {
// 	// Check that caller is Org2 (Transporter)
// 	org, err := ctx.GetClientIdentity().GetMSPID()
// 	if err != nil {
// 		return fmt.Errorf("could not get MSP ID: %v", err)
// 	}
// 	if org != "Org2MSP" {
// 		return fmt.Errorf("unauthorized: only Org2 can acknowledge receipt from Org1")
// 	}

// 	// Read existing batch
// 	vaccine, err := v.ReadBatch(ctx, batchID)
// 	if err != nil {
// 		return fmt.Errorf("failed to read batch: %v", err)
// 	}

// 	// Check that status is IN-TRANSIT
// 	if vaccine.Status != "In-Transit" {
// 		return fmt.Errorf("batch %s is not in transit (current status: %s)", batchID, vaccine.Status)
// 	}

// 	vaccineBytes, err := json.Marshal(vaccine)
// 	if err != nil {
// 		return fmt.Errorf("failed to marshal vaccine batch: %v", err)
// 	}

// 	return ctx.GetStub().PutState(batchID, vaccineBytes)
// }

func (v *VaxContract) ReceiveFromOrg1(ctx contractapi.TransactionContextInterface, batchID string) error {
	// Ensure only Org2 can receive
	org, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return fmt.Errorf("could not get MSP ID: %v", err)
	}
	if org != "Org2MSP" {
		return fmt.Errorf("unauthorized: only Org2 can acknowledge receipt from Org1")
	}

	// Read existing batch
	vaccine, err := v.ReadBatch(ctx, batchID)
	if err != nil {
		return fmt.Errorf("failed to read batch: %v", err)
	}

	// Check that status is IN-TRANSIT
	if vaccine.Status != "In-Transit" {
		return fmt.Errorf("batch %s is not in transit (current status: %s)", batchID, vaccine.Status)
	}

	// Update status to Delivered
	vaccine.Status = "Delivered"

	vaccineBytes, err := json.Marshal(vaccine)
	if err != nil {
		return fmt.Errorf("failed to marshal vaccine batch: %v", err)
	}

	// Save updated batch
	err = ctx.GetStub().PutState(batchID, vaccineBytes)
	if err != nil {
		return fmt.Errorf("failed to store updated batch: %v", err)
	}

	// Create receipt
	receiptKey := "RECEIVED_" + batchID
	receiptValue := "Received by Org2 at " + time.Now().Format(time.RFC3339)
	err = ctx.GetStub().PutState(receiptKey, []byte(receiptValue))
	if err != nil {
		return fmt.Errorf("failed to write receipt: %v", err)
	}

	return nil
}

// // Org 2
// func (v *VaxContract) AddTemperatureLog(ctx contractapi.TransactionContextInterface, batchID string, temperature float64) error {
// 	// Restrict access to Org2 only
// 	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
// 	if err != nil {
// 		return fmt.Errorf("failed to get MSP ID: %v", err)
// 	}
// 	if clientOrgID != "Org2MSP" {
// 		return fmt.Errorf("unauthorized: only Org2 can log temperature data, your MSP is %s", clientOrgID)
// 	}

// 	// Read the existing batch
// 	vaccine, err := v.ReadBatch(ctx, batchID)
// 	if err != nil {
// 		return fmt.Errorf("failed to read batch %s: %v", batchID, err)
// 	}

// 	// Ensure TemperatureLogs is initialized
// 	if vaccine.TemperatureLogs == nil {
// 		vaccine.TemperatureLogs = []TempLog{}
// 	}

// 	// Get the blockchain timestamp
// 	txTimestamp, err := ctx.GetStub().GetTxTimestamp()
// 	if err != nil {
// 		return fmt.Errorf("failed to get transaction timestamp: %v", err)
// 	}
// 	timestamp := txTimestamp.AsTime().Format(time.RFC1123)

// 	// Append the new temperature reading
// 	vaccine.TemperatureLogs = append(vaccine.TemperatureLogs, TempLog{
// 		TimeStamp:   timestamp,
// 		Temperature: temperature,
// 	})

// 	// Marshal and update state
// 	updatedVaccineBytes, err := json.Marshal(vaccine)
// 	if err != nil {
// 		return fmt.Errorf("failed to marshal updated vaccine: %v", err)
// 	}

// 	// If you're using private data collection:
// 	collection := getCollectionName()
// 	return ctx.GetStub().PutPrivateData(collection, batchID, updatedVaccineBytes)

//		// If you're using public data (not recommended for sensitive info):
//		// return ctx.GetStub().PutState(batchID, updatedVaccineBytes)
//	}
func (v *VaxContract) AddTemperatureLog(ctx contractapi.TransactionContextInterface, batchID string, temperature float64) error {
	// Org2-only check
	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return fmt.Errorf("failed to get MSP ID: %v", err)
	}
	if clientOrgID != "Org2MSP" {
		return fmt.Errorf("unauthorized: only Org2 can log temperature")
	}

	// Get timestamp
	txTime, err := ctx.GetStub().GetTxTimestamp()
	if err != nil {
		return fmt.Errorf("failed to get timestamp: %v", err)
	}
	timestamp := txTime.AsTime().Format(time.RFC1123)

	// Read existing temperature log if any
	tempDataBytes, err := ctx.GetStub().GetPrivateData("TempLogCollection", batchID)
	var tempEntry TemperatureLogEntry

	if err == nil && tempDataBytes != nil {
		if err := json.Unmarshal(tempDataBytes, &tempEntry); err != nil {
			return fmt.Errorf("failed to unmarshal existing temp log: %v", err)
		}
	} else {
		tempEntry = TemperatureLogEntry{
			BatchID:  batchID,
			TempLogs: []TempLog{},
		}
	}

	// Append new log
	tempEntry.TempLogs = append(tempEntry.TempLogs, TempLog{
		TimeStamp:   timestamp,
		Temperature: temperature,
	})

	// Save back to collection
	updatedBytes, err := json.Marshal(tempEntry)
	if err != nil {
		return fmt.Errorf("failed to marshal temperature log: %v", err)
	}

	return ctx.GetStub().PutPrivateData("TempLogCollection", batchID, updatedBytes)
}

func (v *VaxContract) ReadTemperatureLog(ctx contractapi.TransactionContextInterface, batchID string) (*TemperatureLogEntry, error) {
	data, err := ctx.GetStub().GetPrivateData("TempLogCollection", batchID)
	if err != nil {
		return nil, fmt.Errorf("failed to read private temperature log: %v", err)
	}
	if data == nil {
		return nil, fmt.Errorf("no temperature log found for batch %s", batchID)
	}

	var entry TemperatureLogEntry
	if err := json.Unmarshal(data, &entry); err != nil {
		return nil, fmt.Errorf("unmarshal failed: %v", err)
	}

	return &entry, nil
}

func (v *VaxContract) DeliverToOrg3(ctx contractapi.TransactionContextInterface, batchID string) error {
	// Ensure only Org2 (Transporter) can call this
	org, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return fmt.Errorf("could not get MSP ID: %v", err)
	}
	if org != "Org2MSP" {
		return fmt.Errorf("unauthorized: only Org2 can deliver to Org3")
	}

	// Read batch
	vaccine, err := v.ReadBatch(ctx, batchID)
	if err != nil {
		return fmt.Errorf("failed to read batch: %v", err)
	}

	// Ensure current status is IN-TRANSIT
	if vaccine.Status != "In-Transit" {
		return fmt.Errorf("batch %s must be in transit to deliver (current status: %s)", batchID, vaccine.Status)
	}

	// Update status
	vaccine.Status = "Delivered"

	// Marshal and save
	vaccineBytes, err := json.Marshal(vaccine)
	if err != nil {
		return fmt.Errorf("failed to marshal batch: %v", err)
	}

	return ctx.GetStub().PutState(batchID, vaccineBytes)
}

func (v *VaxContract) ReceiveFromOrg2(ctx contractapi.TransactionContextInterface, batchID string) error {
	// Ensure only Org3 can receive
	org, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return fmt.Errorf("could not get MSP ID: %v", err)
	}
	if org != "Org3MSP" {
		return fmt.Errorf("unauthorized: only Org3 can receive from Org2")
	}

	// Read batch
	vaccine, err := v.ReadBatch(ctx, batchID)
	if err != nil {
		return fmt.Errorf("failed to read batch: %v", err)
	}

	// Check status
	if vaccine.Status != "Delivered" {
		return fmt.Errorf("batch %s not ready for Org3 to receive (status: %s)", batchID, vaccine.Status)
	}

	// Update status
	vaccine.Status = "Recived"

	vaccineBytes, err := json.Marshal(vaccine)
	if err != nil {
		return fmt.Errorf("failed to marshal batch: %v", err)
	}

	return ctx.GetStub().PutState(batchID, vaccineBytes)
}

func (v *VaxContract) ViewStatus(ctx contractapi.TransactionContextInterface, batchID string) (string, error) {
	vaccine, err := v.ReadBatch(ctx, batchID)
	if err != nil {
		return "", fmt.Errorf("failed to read batch: %v", err)
	}
	return vaccine.Status, nil
}

// func (v *VaxContract) ReceiveFromOrg2(ctx contractapi.TransactionContextInterface, batchID string) error {
// 	// Ensure only Org3 can receive
// 	org, err := ctx.GetClientIdentity().GetMSPID()
// 	if err != nil {
// 		return fmt.Errorf("could not get MSP ID: %v", err)
// 	}
// 	if org != "Org3MSP" {
// 		return fmt.Errorf("unauthorized: only Org3 can receive batches from Org2")
// 	}

// 	// Read the batch from public state (delivered by Org2)
// 	vaccineBytes, err := ctx.GetStub().GetState(batchID)
// 	if err != nil {
// 		return fmt.Errorf("failed to get batch from state: %v", err)
// 	}
// 	if vaccineBytes == nil {
// 		return fmt.Errorf("batch %s not found in public state", batchID)
// 	}

// 	var vaccine VaccineBatch
// 	err = json.Unmarshal(vaccineBytes, &vaccine)
// 	if err != nil {
// 		return fmt.Errorf("failed to unmarshal batch: %v", err)
// 	}

// 	// Update ownership and status
// 	vaccine.Status = "Received"
// 	vaccine.CurrentOwner = "Org3"

// 	// Append to history
// 	vaccine.History = append(vaccine.History, BatchHistory{
// 		TimeStamp: time.Now().Format(time.RFC1123),
// 		Status:    "Received",
// 		Owner:     "Org3",
// 	})

// 	// Marshal and write to private collection
// 	privateBytes, err := json.Marshal(vaccine)
// 	if err != nil {
// 		return fmt.Errorf("failed to marshal updated vaccine batch: %v", err)
// 	}

// 	return ctx.GetStub().PutPrivateData(getCollectionName(), batchID, privateBytes)
// }

// Only Org3 can view temperature history
func (v *VaxContract) GetTempHistory(ctx contractapi.TransactionContextInterface, batchID string) ([]*TempLog, error) {
	// Enforce Org3-only access
	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return nil, fmt.Errorf("failed to get MSP ID: %v", err)
	}
	if clientOrgID != "Org3MSP" {
		return nil, fmt.Errorf("unauthorized: only Org3 can view temperature history, your MSP is %s", clientOrgID)
	}

	// Retrieve historical data for the given batch ID
	resultsIterator, err := ctx.GetStub().GetHistoryForKey(batchID)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	var records []*TempLog

	for resultsIterator.HasNext() {
		response, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}

		// Skip deleted or empty states
		if response.IsDelete || len(response.Value) == 0 {
			continue
		}

		var vaccine VaccineBatch
		err = json.Unmarshal(response.Value, &vaccine)
		if err != nil {
			// Skip if the data is malformed
			continue
		}

		if vaccine.TemperatureLogs == nil || len(vaccine.TemperatureLogs) == 0 {
			continue
		}

		// Use blockchain timestamp
		timestamp := response.Timestamp.AsTime()
		formattedTime := timestamp.Format(time.RFC1123)

		// Append each temperature log with version time
		for _, log := range vaccine.TemperatureLogs {
			record := &TempLog{
				TimeStamp:   formattedTime,
				Temperature: log.Temperature,
			}
			records = append(records, record)
		}
	}

	return records, nil
}

func (v *VaxContract) GetTemperatureLogs(ctx contractapi.TransactionContextInterface, batchID string) ([]TempLog, error) {
	dataBytes, err := ctx.GetStub().GetPrivateData("TempLogCollection", batchID)
	if err != nil {
		return nil, fmt.Errorf("failed to get temperature logs: %v", err)
	}
	if dataBytes == nil {
		return nil, fmt.Errorf("no temperature logs found for batch %s", batchID)
	}

	var entry TemperatureLogEntry
	if err := json.Unmarshal(dataBytes, &entry); err != nil {
		return nil, fmt.Errorf("failed to unmarshal temperature logs: %v", err)
	}

	return entry.TempLogs, nil
}

func (v *VaxContract) ReceiveFromOrg2AndVerifyTemp(ctx contractapi.TransactionContextInterface, batchID string, minTemp, maxTemp float64) error {
	// Check Org3 authorization
	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return fmt.Errorf("failed to get MSP ID: %v", err)
	}
	if clientOrgID != "Org3MSP" {
		return fmt.Errorf("unauthorized: only Org3 can verify temperature logs, your MSP is %s", clientOrgID)
	}

	// Read batch
	vaccine, err := v.ReadBatch(ctx, batchID)
	if err != nil {
		return fmt.Errorf("failed to read batch %s: %v", batchID, err)
	}

	// Check if batch was delivered
	if vaccine.Status != "Delivered" {
		return fmt.Errorf("batch %s not ready for verification (status: %s)", batchID, vaccine.Status)
	}

	// Ensure there are temperature logs
	if len(vaccine.TemperatureLogs) == 0 {
		return fmt.Errorf("no temperature logs found for batch %s", batchID)
	}

	// Check all temperature logs are within range
	for _, log := range vaccine.TemperatureLogs {
		if log.Temperature < minTemp || log.Temperature > maxTemp {
			return fmt.Errorf("temperature %.2f°C out of range (allowed %.2f°C - %.2f°C)", log.Temperature, minTemp, maxTemp)
		}
	}

	// All temperatures are valid
	vaccine.Status = "Verified"

	vaccineBytes, err := json.Marshal(vaccine)
	if err != nil {
		return fmt.Errorf("failed to marshal verified vaccine: %v", err)
	}

	return ctx.GetStub().PutState(batchID, vaccineBytes)
}
